package ast.Expresiones.Accesos;

public enum KindA {
    ACCESOSTRUCTX, ACCESOLISTX, ACCESOPUNTERO, ACCESODIR, ACCESOVAR
}
