package ast.Declaraciones;

public enum KindD {
    DECVAR, DECSTRUCT, DECFUNCION, DECPARAMETRO, DECALIAS
}