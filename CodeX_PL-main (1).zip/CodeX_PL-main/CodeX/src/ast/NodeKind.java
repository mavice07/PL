package ast;

public enum NodeKind {
  EXPRESION, INSTRUCCION, DECLARACION, MAIN, PROGRAMA, TYPE
}