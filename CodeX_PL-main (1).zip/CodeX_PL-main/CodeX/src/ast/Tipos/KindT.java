package ast.Tipos;

public enum KindT {
    INTX, BOOLX, VOIDX, LISTX, STRUCTX, PUNTERO, ALIASX
}
