package ast.Instrucciones;

public enum KindI {
    IF, FOR, WHILE, DECVAR, ASIGNACION, RETURN, READ, WRITE, LLAMADAFUN
}
