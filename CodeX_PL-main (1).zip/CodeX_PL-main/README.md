# CodeX_PL
Desarrollo de un compilador del lenguaje inventado CodeX. Práctica hecha por Pablo Navarro Cebrián y Marta Vicente Navarro.

Para compilar y ejecutar los ejemplos, nos situamos en el directorio CodeX_PL/CodeX. Primero ejecutamos el script generateAllFiles.sh. Este puede recibir el argumento -a (para generar los archivos wasm de todos los ejemplos), recibir el nombre de un fichero (para sólo generar de ese fichero) o no recibir ningún argumento (se generará el fichero wasm el ejemplo ficherosPrueba/programa_prueba.txt). Tras ello, para ejecutar los ejemplos ejecutamos runWasm.sh con el fichero wasm que queramos.
